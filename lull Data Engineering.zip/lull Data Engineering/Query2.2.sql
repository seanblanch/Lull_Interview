
SELECT 
	marketing.ad_network,
	marketing.source,
    -- Total Number of Orders Placed per Marketing ID
    #returns the best performing marketing ad-network and source
    #by adding all the product quantities
    #and using a window function to sum over the product_id and marketing_id
    SUM(orders.product_quantity) OVER
		(PARTITION BY marketing_id, product_id) as bestSellingByQuantity,
        #counts how many orders it had
        #by counting all the marketing_id
	count(marketing.id) OVER 
		(PARTITION BY marketing_id) as numberOfRecords,
        #returning the product name that had the best selling product
        #for that ad network and source
	products.name
FROM marketing
JOIN marketing_orders ON marketing.id=marketing_orders.marketing_id
JOIN orders ON marketing_orders.order_id=orders.id
JOIN products ON orders.product_id=products.id
WHERE marketing_orders.marketing_id = marketing.id
#GROUP BY marketing.id
ORDER BY numberOfRecords DESC, bestSellingByQuantity DESC
LIMIT 1;

SELECT *,     SUM(orders.product_quantity) OVER
		(PARTITION BY marketing_id, products.id) as ordersSold
FROM marketing
LEFT JOIN marketing_orders ON marketing.id=marketing_orders.marketing_id
LEFT JOIN orders ON marketing_orders.order_id=orders.id
LEFT JOIN products ON orders.product_id=products.id