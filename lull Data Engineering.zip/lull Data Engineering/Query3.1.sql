#3.	Write a query that determines the best selling product for each month of orders. 
#Also include the output of the query.

#CTE - Wrap data in CTE to reuse sumed up value w/o using the functions again
WITH productQuantity AS (
SELECT  
	products.name,
    sum(orders.product_quantity) as total_number_ordered_in_month, #based on groupby
    date_format(ordered_at, '%b') as order_month #formated to only show Month
FROM orders
JOIN products ON orders.product_ID=products.id # to get products name
GROUP BY MONTH(ordered_at), products.name 
)
#Filter data to grab the max quantity ordered for each month
SELECT *
FROM productQuantity
WHERE total_number_ordered_in_month =
		(SELECT
        max(total_number_ordered_in_month)
        FROM productQuantity as a
        #(IE. Jan = Jan, Feb = Feb, ...
        #Therefore it only produces 1 result and not 2+ results for each row)
        WHERE a.order_month = productQuantity.order_month
        GROUP BY order_month);
        
        