

Create table products(
	id int,
    name varchar(100),
    description varchar(100),
    go_live_date date,
    created_at datetime,
    updated_at datetime,
    PRIMARY KEY (id)
);

Create table orders(
	id int,
    product_id int,
    ordered_at datetime,
    product_quantity varchar(10),
    created_at datetime,
    updated_at datetime,
    PRIMARY KEY (id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

Create table marketing(
	id int,
    ad_network varchar(50),
    source varchar(50),
    created_at datetime,
    updated_at datetime,
    PRIMARY KEY (id)
);

Create table marketing_orders(
	order_id int,
    marketing_id int,
    PRIMARY KEY (order_id, marketing_id),
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (marketing_id) REFERENCES marketing(id)
);