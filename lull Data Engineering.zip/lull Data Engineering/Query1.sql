SELECT orders.id,
products.name,
DATEDIFF(orders.ordered_at, products.go_live_date) AS daysBetweenProductGoLiveVsOrdered,
marketing.ad_network,
marketing.source
FROM orders
JOIN products ON orders.product_ID=products.id #to get products name, go_live_date
LEFT JOIN marketing_orders ON orders.id=marketing_orders.order_id
LEFT JOIN marketing ON marketing_orders.marketing_id=marketing.id;