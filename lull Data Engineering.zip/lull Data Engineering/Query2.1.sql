
SELECT 
	marketing.ad_network,
	marketing.source,
    -- Total Number of Orders Placed per Marketing ID
    #subquery that returns the best performing marketing ad-network and source
    #by adding all the product quantities
    #and using marketing-ordering to see if it was ads or remarketing
	(SELECT 
		SUM(orders.product_quantity)
		FROM orders
        JOIN marketing_orders ON orders.id=marketing_orders.order_id
        WHERE marketing_orders.marketing_id = marketing.id
        GROUP BY marketing_orders.marketing_id) as ordersSold,
        #subquery that counts how many orders it had
        #by counting all the marketing_id
    (SELECT
		count(marketing_orders.marketing_id)
        FROM marketing_orders
        WHERE marketing_orders.marketing_id = marketing.id
        GROUP BY marketing_orders.marketing_id) as orderCount,
        #subquery returning the product name that had the best selling product
        #for that ad network and source
	(SELECT
		products.name
        FROM products
        JOIN orders on products.id=orders.product_id
        JOIN marketing_orders on orders.id=marketing_orders.order_id
        WHERE product_quantity = (SELECT MAX(product_quantity) FROM orders)
        GROUP BY marketing_orders.marketing_id) as bestSellingProduct
FROM marketing
ORDER BY ordersSold DESC
LIMIT 1;