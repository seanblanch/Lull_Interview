#Sean Blanchard
#7/8/2021
#Coding Interview

# Write python code that can take csv and convert it into an array of json OR take an array of JSON and convert it into a CSV file with the same column names.
# This code should be able to write to a file in either CSV or JSON format, the user should be able to pick the output type.
# If someone picks the same output type as the input type it should write out that file still.

import csv, json, yaml, sys

def switch():
    # This will guide the user to choose option
    print("Press 1 for CSV to JSON\nPress 2 for CSV to YAML\nPress 3 for JSON to CSV\nPress 4 for JSON to YAML")

    # This will take option from user
    option = int(input(" your option : "))

    # Read the CSV and add the data to a dictionary
    def CSVtoJSON():
        #Sample CSV
        csvFilePath = "cleaned_hm.csv"
        #Outputfile
        jsonFilePath = "happy.json"
        #dictionary to store data
        data = {}
        #open file
        with open(csvFilePath) as csvFile:
            csvReader = csv.DictReader(csvFile)
            #loop through each row
            for csvRow in csvReader:
                #look at data, get the ID of each line
                hmid = csvRow["hmid"]
                #add data to data dictionary
                data[hmid] = csvRow

        #Prints the data
        print(data)

        #Write data to a JSON file
        with open(jsonFilePath, "w") as jsonFile:
            jsonFile.write(json.dumps(data, indent=4)) #Indent helps with formatting

        print(jsonFilePath, " Converted to ", csvFilePath)

    def CSVtoYAML():
        # Sample CSV
        csvFilePath = "test.csv"
        # Outputfile
        yamlFilePath = "CSVtoYAMLTest.yaml"
        # dictionary to store data
        data = {}
        # open file
        with open(csvFilePath) as csvFile:
            csvReader = csv.DictReader(csvFile)
            # loop through each row
            for csvRow in csvReader:
                # look at data, get the ID of each line
                hmid = csvRow["firstName"]
                # add data to data dictionary
                data[hmid] = csvRow

        # Prints the data
        print(data)

        with open(yamlFilePath, "w") as yamlFile:
            yamlFile.write(yaml.dump(data))

    def JSONtoCSV():
        # Sample CSV
        jsonFilePath = "sample4.json"
        # Outputfile
        csvFilePath = "test.csv"

        # Opening JSON file and loading the data
        # into the variable data
        with open(jsonFilePath) as json_file:
            data = json.load(json_file)

        employee_data = data['people']

        # now we will open a file for writing
        data_file = open(csvFilePath, 'w')

        # create the csv writer object
        csv_writer = csv.writer(data_file)

        # Counter variable used for writing
        # headers to the CSV file
        count = 0

        for emp in employee_data:
            if count == 0:
                # Writing headers of CSV file
                header = emp.keys()
                csv_writer.writerow(header)
                count += 1

            # Writing data of CSV file
            csv_writer.writerow(emp.values())

        data_file.close()
        print(jsonFilePath, " Converted to ", csvFilePath)

    def JSONtoYAML():
        # Outputfile
        yamlFilePath = "JSONtoYAMLTest.yaml"

        print(yaml.dump(json.load(open("sample4.json"))))

        with open(yamlFilePath, "w") as yamlFile:
            #jsonFile.write(json.dumps(yaml.dump(json.load(open("sample4.json"))), indent=8))
            yamlFile.write(yaml.dump(json.load(open("sample4.json"))))

    # If user enters invalid option then this method will be called
    def default():
        print("Incorrect option")

    # Dictionary Mapping
    dict = {
        1: CSVtoJSON,
        2: CSVtoYAML,
        3: JSONtoCSV,
        4: JSONtoYAML,

    }
    dict.get(option, default)()  # get() method returns the function matching the argument


switch()  # Call switch() method
