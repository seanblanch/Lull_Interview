INSERT INTO products (id, name, description, go_live_date, created_at, updated_at) VALUES (1, 'Mattress', 'A Mattress', '2021-01-01', '2020-12-01 00:00:01', '2020-12-01 00:00:00');
INSERT INTO products (id, name, description, go_live_date, created_at, updated_at) VALUES (3, 'Pillow', 'A Pillow', '2021-01-01', '2020-12-01 00:00:00', '2020-12-01 00:00:00');
INSERT INTO products (id, name, description, go_live_date, created_at, updated_at) VALUES (5, 'Comforter', 'A Comforter', '2021-01-01', '2020-12-01 00:00:00', '2020-12-01 00:00:00');

INSERT INTO orders (id, product_id, ordered_at, product_quantity, created_at, updated_at) VALUES (1, 3, '2021-01-01 00:00:00', '1', '2021-01-01 00:00:01', '2021-01-01 00:01:03');
INSERT INTO orders (id, product_id, ordered_at, product_quantity, created_at, updated_at) VALUES (2, 1, '2021-01-03 05:00:07', '4', '2021-01-03 05:00:08', '2021-01-03 05:02:12');
INSERT INTO orders (id, product_id, ordered_at, product_quantity, created_at, updated_at) VALUES (3, 5, '2021-01-05 12:05:00', '3', '2021-01-05 12:05:01', '2021-01-06 01:05:00');
INSERT INTO orders (id, product_id, ordered_at, product_quantity, created_at, updated_at) VALUES (4, 1, '2021-02-01 03:00:00', '2', '2021-02-01 03:00:01', '2021-02-01 03:00:01');
INSERT INTO orders (id, product_id, ordered_at, product_quantity, created_at, updated_at) VALUES (5, 1, '2021-02-05 00:00:00', '3', '2021-02-05 00:00:01', '2021-02-05 00:00:01');

INSERT INTO marketing (id, ad_network, source, created_at, updated_at) VALUES (1, 'facebook', 'ads', '2020-12-01 00:00:00', '2020-12-01 00:00:00');
INSERT INTO marketing (id, ad_network, source, created_at, updated_at) VALUES (2, 'facebook', 'remarketing', '2020-12-01 00:00:00', '2020-12-01 00:00:00');

INSERT INTO marketing_orders (order_id, marketing_id) VALUES (1, 1);
INSERT INTO marketing_orders (order_id, marketing_id) VALUES (2, 1);
INSERT INTO marketing_orders (order_id, marketing_id) VALUES (3, 2);